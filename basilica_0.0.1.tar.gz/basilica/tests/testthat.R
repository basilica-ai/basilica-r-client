library(testthat)
library(basilica)

test_check("basilica")
